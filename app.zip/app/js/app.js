    'use strict';

    angular.module('annuityApp', [
        'ngRoute',
        'annuityApp.infoService',
        'annuityApp.main',
        'annuityApp.news',
        'annuityApp.details',
        'annuityApp.annuity',
        'annuityApp.groupIns',
        'annuityApp.pension',
        'annuityApp.preview',
        'annuityApp.principal',
        'annuityApp.delegate',
        'annuityApp.medical',
        'annuityApp.static'
    ])

    angular.module('annuityApp.annuity', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/annuity', {
            templateUrl: 'modules/annuity/annuity.html',
            controller: 'annuityCtrl'
        });
    }])

    .controller('annuityCtrl', ['$scope', function($scope){

    }]);

    angular.module('annuityApp.delegate', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider
            .when('/delegate', {
                templateUrl: 'modules/delegate/delegate.html',
                controller: 'delegateCtrl'
            })
            .when('/delegate/personal', {
                templateUrl: 'modules/delegate/personal.html',
                controller: 'delegatePersonalCtrl'
            })
            .when('/delegate/team', {
                templateUrl: 'modules/delegate/team.html',
                controller: 'delegateTeamCtrl'
            })
            .when('/delegate/personal/pproBakClause', {
                templateUrl: 'modules/delegate/list.html',
                controller: 'pproBakClauseCtrl'
            })
            .when('/delegate/personal/pproChgMatter', {
                templateUrl: 'modules/delegate/list.html',
                controller: 'pproChgMatterCtrl'
            })
            .when('/delegate/personal/pproBuildBulletin', {
                templateUrl: 'modules/delegate/list.html',
                controller: 'pproBuildBulletinCtrl'
            })
            .when('/delegate/personal/pproRaiseBulletin', {
                templateUrl: 'modules/delegate/list.html',
                controller: 'pproRaiseBulletinCtrl'
            })
            .when('/delegate/personal/pproYearEquityReport', {
                templateUrl: 'modules/delegate/list.html',
                controller: 'pproYearEquityReportCtrl'
            })
            .when('/delegate/personal/prelatedPolicyLaw', {
                templateUrl: 'modules/delegate/list.html',
                controller: 'prelatedPolicyLawCtrl'
            })
            .when('/delegate/personal/pserverGuide', {
                templateUrl: 'modules/delegate/list.html',
                controller: 'pserverGuide.html'
            })
            .when('/delegate/team/tproBakClause', {
                templateUrl: 'modules/delegate/list.html',
                controller: 'tproBakClauseCtrl'
            })
            .when('/delegate/team/tproChgMatter', {
                templateUrl: 'modules/delegate/list.html',
                controller: 'tproChgMatterCtrl'
            })
            .when('/delegate/team/tproYearEquityReport', {
                templateUrl: 'modules/delegate/list.html',
                controller: 'tproYearEquityReportCtrl'
            })
            .when('/delegate/team/trelatedPolicyLaw', {
                templateUrl: 'modules/delegate/list.html',
                controller: 'trelatedPolicyLawCtrl'
            })
    }])

    .controller('delegateCtrl', ['$scope', 'infoService', '$routeParams', function($scope, infoService, $routeParams){

        $scope.title = "委托产品";

    }])

    .controller('delegatePersonalCtrl', ['$scope', 'infoService', function($scope, infoService){

    }])

    .controller('delegateTeamCtrl', ['$scope', 'infoService', function($scope, infoService){

    }])

    .controller('pproBakClauseCtrl', ['$scope', 'infoService', function($scope, infoService){

        $scope.title = '产品备案条款';
        $scope.back = 'delegate/personal';

        $scope.infoList = [];
        $scope.infoBufferNum = 20;
        $scope.totalNum = 0;
        $scope.currentTabs = 0;

        initInfoList();
        //init infoList
        function initInfoList() {
            loadRemoteData({
                method: "articleList",
                channelId: 205,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data) {
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params) {
            infoService.getInfoList(params).then(function(data) {
                applyRemoteData(data);
            });
        }

    }])

    .controller('pproChgMatterCtrl', ['$scope', 'infoService', function($scope, infoService){

        $scope.title = '产品变动事项';
        $scope.back = 'delegate/personal';

        $scope.infoList = [];
        $scope.infoBufferNum = 20;
        $scope.totalNum = 0;
        $scope.currentTabs = 0;

        initInfoList();
        //init infoList
        function initInfoList() {
            loadRemoteData({
                method: "articleList",
                channelId: 599,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data) {
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params) {
            infoService.getInfoList(params).then(function(data) {
                applyRemoteData(data);
            });
        }

    }])

    .controller('pproBuildBulletinCtrl', ['$scope', 'infoService', function($scope, infoService){

        $scope.title = '产品成立公告';
        $scope.back = 'delegate/personal';

        $scope.infoList = [];
        $scope.infoBufferNum = 20;
        $scope.totalNum = 0;
        $scope.currentTabs = 0;

        initInfoList();
        //init infoList
        function initInfoList() {
            loadRemoteData({
                method: "articleList",
                channelId: 600,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data) {
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params) {
            infoService.getInfoList(params).then(function(data) {
                applyRemoteData(data);
            });
        }
    }])

    .controller('pproRaiseBulletinCtrl', ['$scope', 'infoService', function($scope, infoService){

        $scope.title = '产品募集公告款';
        $scope.back = 'delegate/personal';

        $scope.infoList = [];
        $scope.infoBufferNum = 20;
        $scope.totalNum = 0;
        $scope.currentTabs = 0;

        initInfoList();
        //init infoList
        function initInfoList() {
            loadRemoteData({
                method: "articleList",
                channelId: 602,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data) {
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params) {
            infoService.getInfoList(params).then(function(data) {
                applyRemoteData(data);
            });
        }
    }])

    .controller('pproYearEquityReportCtrl', ['$scope', 'infoService', function($scope, infoService){
        $scope.title = '产品年度权益报告';
        $scope.back = 'delegate/personal';

        $scope.infoList = [];
        $scope.infoBufferNum = 20;
        $scope.totalNum = 0;
        $scope.currentTabs = 0;

        initInfoList();
        //init infoList
        function initInfoList() {
            loadRemoteData({
                method: "articleList",
                channelId: 602,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data) {
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params) {
            infoService.getInfoList(params).then(function(data) {
                applyRemoteData(data);
            });
        }
    }])

    .controller('prelatedPolicyLawCtrl', ['$scope', 'infoService', function($scope, infoService){
        $scope.title = '相关政策法规';
        $scope.back = 'delegate/personal';

        $scope.infoList = [];
        $scope.infoBufferNum = 20;
        $scope.totalNum = 0;
        $scope.currentTabs = 0;

        initInfoList();
        //init infoList
        function initInfoList() {
            loadRemoteData({
                method: "articleList",
                channelId: 603,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data) {
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params) {
            infoService.getInfoList(params).then(function(data) {
                applyRemoteData(data);
            });
        }
    }])

    .controller('pserverGuideCtrl', ['$scope', 'infoService', function($scope, infoService){
        $scope.title = '服务指引';
        $scope.back = 'delegate/personal';

        $scope.infoList = [];
        $scope.infoBufferNum = 20;
        $scope.totalNum = 0;
        $scope.currentTabs = 0;

        initInfoList();
        //init infoList
        function initInfoList() {
            loadRemoteData({
                method: "articleList",
                channelId: 604,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data) {
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params) {
            infoService.getInfoList(params).then(function(data) {
                applyRemoteData(data);
            });
        }
    }])

    .controller('tproBakClauseCtrl', ['$scope', 'infoService', function($scope, infoService){
        $scope.title = '产品备案条款';
        $scope.back = 'delegate/team';

        $scope.infoList = [];
        $scope.infoBufferNum = 20;
        $scope.totalNum = 0;
        $scope.currentTabs = 0;

        initInfoList();
        //init infoList
        function initInfoList() {
            loadRemoteData({
                method: "articleList",
                channelId: 206,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data) {
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params) {
            infoService.getInfoList(params).then(function(data) {
                applyRemoteData(data);
            });
        }
    }])

    .controller('tproChgMatterCtrl', ['$scope', 'infoService', function($scope, infoService){
        $scope.title = '产品变动事项';
        $scope.back = 'delegate/team';

        $scope.infoList = [];
        $scope.infoBufferNum = 20;
        $scope.totalNum = 0;
        $scope.currentTabs = 0;

        initInfoList();
        //init infoList
        function initInfoList() {
            loadRemoteData({
                method: "articleList",
                channelId: 605,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data) {
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params) {
            infoService.getInfoList(params).then(function(data) {
                applyRemoteData(data);
            });
        }
    }])

    .controller('tproYearEquityReportCtrl', ['$scope', 'infoService', function($scope, infoService){
        $scope.title = '产品年度权益报告';
        $scope.back = 'delegate/team';

        $scope.infoList = [];
        $scope.infoBufferNum = 20;
        $scope.totalNum = 0;
        $scope.currentTabs = 0;

        initInfoList();
        //init infoList
        function initInfoList() {
            loadRemoteData({
                method: "articleList",
                channelId: 606,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data) {
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params) {
            infoService.getInfoList(params).then(function(data) {
                applyRemoteData(data);
            });
        }
    }])

    .controller('trelatedPolicyLawCtrl', ['$scope', 'infoService', function($scope, infoService){
        $scope.title = '相关政策法规';
        $scope.back = 'delegate/team';

        $scope.infoList = [];
        $scope.infoBufferNum = 20;
        $scope.totalNum = 0;
        $scope.currentTabs = 0;

        initInfoList();
        //init infoList
        function initInfoList() {
            loadRemoteData({
                method: "articleList",
                channelId: 607,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data) {
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params) {
            infoService.getInfoList(params).then(function(data) {
                applyRemoteData(data);
            });
        }
    }]);

angular.module('annuityApp.details', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
    $routeProvider.when('/details/:articleId', {
        templateUrl: 'modules/details/details.html',
        controller: 'detailsCtrl'
    });
}])

.controller('detailsCtrl', ['$scope', '$routeParams', 'infoService', '$rootScope', function($scope, $routeParams, infoService, $rootScope) {

    $scope.$routeParams = $routeParams;
    $scope.article = {};
    $scope.articleContent = "";
    $scope.backLink = !!$rootScope.previousRouter && $rootScope.previousRouter.originalPath || 'main';

    initArticle();

    //init infoList
    function initArticle(){
        loadRemoteData({
            method: "articleDetail",
            articleId: $scope.$routeParams.articleId
        });
    }

    function applyRemoteData(data){
        $scope.article = data;
        $scope.title = (!!$rootScope.previousRouter && ($rootScope.previousRouter.originalPath == "/news" || $rootScope.previousRouter.originalPath == "/main")) ? "详情" : $scope.article.articleTitle;
        angular.element('#strBuffer').html($scope.article.articleContent);
        angular.element('#content').html(angular.element('#strBuffer').text());
    }


    function loadRemoteData(params){
        infoService.getDetails(params).then(function(data){
            applyRemoteData(data);
        });
    }

}])

.filter('to_trusted', ['$sce', function($sce){
    return function(text) {
        return $sce.trustAsHtml(text);
    };
}]);

angular.module('annuityApp.groupIns', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
    $routeProvider
        .when('/groupIns', {
            templateUrl: 'modules/groupIns/groupIns.html',
            controller: 'groupInsCtrl'
        })
        .when('/groupIns/personal', {
            templateUrl: 'modules/groupIns/personal.html',
            controller: 'groupInsPsCtrl'
        })
        .when('/groupIns/company', {
            templateUrl: 'modules/groupIns/company.html',
            controller: 'groupInsCyCtrl'
        })
        .when('/groupIns/jbd', {
            templateUrl: 'modules/groupIns/jbd.html',
            controller: 'groupInsJbCtrl'
        })
        .when('/groupIns/company/smallTeamPro', {
            templateUrl: 'modules/groupIns/smallTeamPro.html',
            controller: 'groupInsSmallTeamProCtrl'
        })
        .when('/groupIns/company/bigTeamPro', {
            templateUrl: 'modules/groupIns/bigTeamPro.html',
            controller: 'groupInsBigTeamProCtrl'
        })
        .when('/groupIns/company/teamIns', {
            templateUrl: 'modules/groupIns/teamIns.html',
            controller: 'groupInsTeamInsoCtrl'
        })
        .when('/groupIns/company/ydl', {
            templateUrl: 'modules/groupIns/ydl.html',
            controller: 'groupInsYdlCtrl'
        })
        .when('/groupIns/company/zht', {
            templateUrl: 'modules/groupIns/zht.html',
            controller: 'groupInsZhtCtrl'
        })
        .when('/groupIns/company/zytc', {
            templateUrl: 'modules/groupIns/zytc.html',
            controller: 'groupInsZytcCtrl'
        })
        .when('/groupIns/jbd/insuranceProducts', {
            templateUrl: 'modules/groupIns/insuranceProducts.html',
            controller: 'insuranceProductsCtr'
        })
        .when('/groupIns/jbd/eService', {
            templateUrl: 'modules/groupIns/eService.html',
            controller: 'eServiceCtr'
        })
        .when('/groupIns/jbd/omnibusService', {
            templateUrl: 'modules/groupIns/omnibusService.html',
            controller: 'omnibusServiceCtr'
        })
        .when('/groupIns/jbd/clientService', {
            templateUrl: 'modules/groupIns/clientService.html',
            controller: 'clientServiceCtr'
        })
        .when('/groupIns/jbd/focusHomework', {
            templateUrl: 'modules/groupIns/focusHomework.html',
            controller: 'focusHomeworkCtr'
        })
        .when('/groupIns/jbd/convenientClient', {
            templateUrl: 'modules/groupIns/convenientClient.html',
            controller: 'convenientClientCtr'
        })
        .when('/groupIns/jbd/globalRescue', {
            templateUrl: 'modules/groupIns/globalRescue.html',
            controller: 'globalRescueCtr'
        })
        .when('/groupIns/jbd/vip', {
            templateUrl: 'modules/groupIns/vip.html',
            controller: 'vipCtr'
        })
        .when('/groupIns/jbd/thanksgiving', {
            templateUrl: 'modules/groupIns/thanksgiving.html',
            controller: 'thanksgivingCtr'
        })
}])

.controller('groupInsCtrl', ['$scope', function($scope){

}])

.controller('groupInsPsCtrl', ['$scope', function($scope){

}])

.controller('groupInsCyCtrl', ['$scope', function($scope){

}])

.controller('groupInsJbCtrl', ['$scope', function($scope){

}])

.controller('groupInsSmallTeamProCtrl', ['$scope', function($scope){

}])

.controller('groupInsBigTeamProCtrl', ['$scope', function($scope){

}])

.controller('groupInsTeamInsoCtrl', ['$scope', function($scope){

}])

.controller('groupInsZhtCtrl', ['$scope', function($scope){

}])

.controller('groupInsZytcCtrl', ['$scope', function($scope){

}])

.controller('groupInsYdlCtrl', ['$scope', function($scope){

}])

.controller('insuranceProductsCtr', ['$scope', function($scope){

}])
.controller('eServiceCtr', ['$scope', function($scope){

}])
.controller('omnibusServiceCtr', ['$scope', function($scope){

}])
.controller('clientServiceCtr', ['$scope', function($scope){

}])
.controller('focusHomeworkCtr', ['$scope', function($scope){

}])
.controller('convenientClientCtr', ['$scope', function($scope){

}])
.controller('globalRescueCtr', ['$scope', function($scope){

}])
.controller('vipCtr', ['$scope', function($scope){

}])
.controller('thanksgivingCtr', ['$scope', function($scope){

}])
    angular.module('annuityApp')

        .controller('headerCtrl', ['$scope', function ($scope) {
            $scope.txt = '平安养老险';
        }]);

    angular.module('annuityApp.main', ['ngRoute'])

        .config(['$routeProvider','$locationProvider',function($routeProvider,$locationProvider) {
            //$locationProvider.html5Mode(true);
            $routeProvider
                .when('/main', {
                    templateUrl: 'modules/main/main.html',
                    controller: 'mainCtrl'
                });
        }])

        .controller('mainCtrl', ['$scope', 'infoService', function($scope, infoService){

            initSwipe();
            $scope.title = '平安养老险',

            $scope.slides = [{
                id: 1,
                img: '/app_images/wap/v30/c3/yanglaoxian/touch/img1.jpg'
            }];

            //mode init

            $scope.tabs = [
            {
                title: '最新资讯',
                channel_id: 212,
                on: true
            },
            {
                title: '视点聚集',
                channel_id: 162,
                on: false
            },
            {
                title: '高端视点',
                channel_id: 211,
                on: false
            },
            {
                title: '高端论述',
                channel_id: 163,
                on: false
            }
            ];

            $scope.infoList = [];

            initInfoList();

            $scope.toggleTabs = function(index){
                //fliter
                if(!!$scope.tabs[index].on){
                    return;
                }
                $scope.tabs.forEach(function(tab, num){
                    num == index ? $scope.tabs[num].on = true : $scope.tabs[num].on = false;
                });
                loadRemoteData({
                    method: 'articleList',
                    channelId: $scope.tabs[index].channel_id,
                    channelLevel: 2,
                    number: 5
                });
            }

            //init infoList
            function initInfoList(){
                loadRemoteData({
                    method: "articleList",
                    channelId: $scope.tabs[0].channel_id,
                    channelLevel: 2,
                    number: 5
                });
            }

            function applyRemoteData(data){
                $scope.infoList = data.articleList;
            }

            function loadRemoteData(params){
                infoService.getInfoList(params).then(function(data){
                    applyRemoteData(data);
                });
            }

            function initSwipe(){
                setTimeout(function(){
                    var adSwiper = new Swiper('#p_rolling',{
                        //Your options here:
                        mode:'horizontal',
                        loop: true,
                        autoplay: 3000,
                        autoplayDisableOnInteraction: false,
                        onSlideChangeEnd: function(self){
                            $("#p_rolling_arrows").find("li")
                            .eq(self.activeLoopIndex).addClass("arrow")
                            .siblings().removeClass("arrow");
                        }
                        //etc..
                    });
                    var toolsSwiper = new Swiper('#p_tools', {
                        mode: 'horizontal',
                        loop: true,
                        onSlideChangeEnd: function(self){
                            $("#p_tools_arrows").find("li")
                            .eq(self.activeLoopIndex).addClass("arrow")
                            .siblings().removeClass("arrow");
                        }
                    });



                },300);
            }

        }]);

angular.module('annuityApp.medical', ['ngRoute'])

.config(['$routeProvider', function($routeProvider) {
    $routeProvider
    .when('/medical', {
        templateUrl: 'modules/medical/medical.html',
        controller: 'medicalCtrl'
    })
    .when('/medical/gansu', {
        templateUrl: 'modules/medical/gansu.html',
        controller: 'medicalGsCtrl'
    })
    .when('/medical/news', {
        templateUrl: 'modules/medical/news.html',
        controller: 'medicalNewsCtrl'
    })
    .when('/medical/policy', {
        templateUrl: 'modules/medical/policy.html',
        controller: 'medicalPolicyCtrl'
    })
}])

.controller('medicalCtrl', ['$scope', 'infoService', function($scope, infoService){

}])

.controller('medicalGsCtrl', ['$scope', function($scope){

}])

.controller('medicalPolicyCtrl', ['$scope', 'infoService', function($scope, infoService){
    $scope.infoList = [];
    $scope.infoBufferNum = 20;
    $scope.totalNum = 0;
    $scope.currentTabs = 0;

    initInfoList();
    //init infoList
    function initInfoList(){
        loadRemoteData({
            method: "articleList",
            channelId: 1085,
            channelLevel: 2,
            number: 20
        });
    }

    function applyRemoteData(data){
        $scope.infoList = data.articleList;
        $scope.totalNum = data.totalNum;
    }

    function loadRemoteData(params){
        infoService.getInfoList(params).then(function(data){
            applyRemoteData(data);
        });
    }
}])

.controller('medicalNewsCtrl', ['$scope', 'infoService', function($scope,infoService){

    $scope.infoList = [];
    $scope.infoBufferNum = 20;
    $scope.totalNum = 0;
    $scope.currentTabs = 0;

    initInfoList();
    //init infoList
    function initInfoList(){
        loadRemoteData({
            method: "articleList",
            channelId: 1084,
            channelLevel: 2,
            number: 20
        });
    }

    function applyRemoteData(data){
        $scope.infoList = data.articleList;
        $scope.totalNum = data.totalNum;
    }

    function loadRemoteData(params){
        infoService.getInfoList(params).then(function(data){
            applyRemoteData(data);
        });
    }
}]);


    angular.module('annuityApp.news', ['ngRoute'])

        .config(['$routeProvider', function($routeProvider) {
          $routeProvider.when('/news', {
            templateUrl: 'modules/news/news.html',
            controller: 'newsCtrl'
          });
        }])

        .controller('newsCtrl', ['$scope', 'infoService', '$location', function($scope, infoService, $location) {

            $scope.title = '资讯信息';

            //mode init

            $scope.tabs = [
            {
                title: '最新资讯',
                channel_id: 212,
                on: true
            },
            {
                title: '视点聚集',
                channel_id: 162,
                on: false
            },
            {
                title: '高端视点',
                channel_id: 211,
                on: false
            },
            {
                title: '高端论述',
                channel_id: 163,
                on: false
            }
            ];

            $scope.infoList = [];
            $scope.infoBufferNum = 20;
            $scope.totalNum = 0;
            $scope.currentTabs = 0;
            $scope.myScroll = null;

            initInfoList();

            $scope.toggleTabs = function(index){
                //fliter
                if(!!$scope.tabs[index].on){
                    return;
                }
                $scope.tabs.forEach(function(tab, num){
                    num == index ? $scope.tabs[num].on = true : $scope.tabs[num].on = false;
                });
                loadRemoteData({
                    method: 'articleList',
                    channelId: $scope.tabs[index].channel_id,
                    channelLevel: 2,
                    number: 20
                });
                $scope.currentTabs = index;
                $scope.infoBufferNum = 20;
            }

            //init infoList
            function initInfoList(){
                loadRemoteData({
                    method: "articleList",
                    channelId: $scope.tabs[0].channel_id,
                    channelLevel: 2,
                    number: 20
                });
            }

            function applyRemoteData(data){
                $scope.infoList = data.articleList;
                $scope.totalNum = data.totalNum;
                !!$scope.myScroll ? (function(){
                    $scope.myScroll.destroy();
                    $scope.myScroll = null;
                    iscrollInit();
                }()) : iscrollInit();
            }

            function loadRemoteData(params){
                infoService.getInfoList(params).then(function(data){
                    applyRemoteData(data);
                });
            }

            function iscrollInit(){

                var pullUpEl,
                    pullUpOffset,
                    scroll_in_progress = false;

                function load_content(refresh) {

                    if (refresh) {
                        $scope.myScroll.refresh();
                        pullActionCallback();

                    } else {

                        if ($scope.myScroll) {
                            $scope.myScroll.destroy();
                            $($scope.myScroll.scroller).attr('style', '');
                            $scope.myScroll = null;
                        }
                        trigger_myScroll();

                    }

                };
                function pullUpAction(callback) {
                    load_content('refresh');
                    !!callback ? callback() : false;
                }
                function pullActionCallback() {
                    infoService
                        .getInfoList({
                            method: "articleList",
                            channelId: $scope.tabs[$scope.currentTabs].channel_id,
                            channelLevel: 2,
                            number: $scope.infoBufferNum + 10
                        })
                        .then(function(data){
                            applyRemoteData(data);
                            $scope.infoBufferNum += 10;
                        });
                }

                function trigger_myScroll(offset) {
                    pullUpEl = document.querySelector('#pullUp');
                    if (pullUpEl) {
                        pullUpOffset = pullUpEl.offsetHeight;
                    } else {
                        pullUpOffset = 0;
                    }
                    if ($('#wrapper ul > li').length >= $scope.totalNum) {
                        $('#pullUp').hide();
                        offset = 0;
                    }
                    else{
                        $('#pullUp').show();
                    }
                    if (!offset) {
                        offset = pullUpOffset;
                    }


                    $scope.myScroll = new IScroll('#wrapper', {
                        probeType:1,
                        tap:true,
                        click:false,
                        preventDefaultException:{tagName:/.*/},
                        mouseWheel:true,
                        scrollbars:true,
                        fadeScrollbars:true,
                        interactiveScrollbars:false,
                        keyBindings:false,
                        deceleration:0.0002,
                        startY:(0)
                    });

                    $scope.myScroll.on('scrollStart', function () {
                        scroll_in_progress = true;
                        $(pullUpEl).addClass('flip');
                    });
                    $scope.myScroll.on('scroll', function () {

                        scroll_in_progress = true;

                        if ($('#wrapper ul > li').length <= $scope.totalNum) {
                            if (this.y >= 5 && pullUpEl && !pullUpEl.className.match('flip')) {
                                pullUpEl.querySelector('.pullUpLabel').innerHTML = '松开立即刷新';
                                this.minScrollY = 0;
                            } else if (this.y <= 5 && pullUpEl && pullUpEl.className.match('flip')) {
                                pullUpEl.querySelector('.pullUpLabel').innerHTML = '上拉刷新';
                                this.minScrollY = -pullUpOffspet;
                            }

                        }
                    });
                    $scope.myScroll.on('scrollEnd', function () {
                        if ($('#wrapper ul > li').length < $scope.totalNum) {
                            if (pullUpEl && pullUpEl.className.match('flip')) {
                                pullUpEl.querySelector('.pullUpLabel').innerHTML = '加载中...';
                                pullUpAction();
                            }
                        }
                    });

                    setTimeout(function() {
                        $('#wrapper').css({left:0});
                    }, 100);
                }

                function loaded() {

                    load_content();

                }
                //开启导致退回主屏划不动
                //document.addEventListener('touchmove', function (e) { e.preventDefault(); }, false);


                setTimeout(function(){
                    loaded();
                }, 200);
            }


        }])

    angular.module('annuityApp.pension', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/pension', {
            templateUrl: 'modules/pension/pension.html',
            controller: 'pensionCtrl'
        });
    }])

    .controller('pensionCtrl', ['$scope', function($scope){
    }]);

    angular.module('annuityApp.preview', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/preview'  , {
            templateUrl: 'modules/preview/preview.html',
            controller: 'previewCtrl'
        });
    }])

    .controller('previewCtrl', ['$scope', '$routeParams', function($scope, $routeParams){
        $scope.path = $routeParams.path;
        $scope.title = $routeParams.name;

        initPdf("/app/images/123.pdf");

        var myService = $resource($routeParams.path, {}, {
            $getPdf: {
                responseType: 'arraybuffer',
                transformResponse: function(data, headersGetter) {
                    // Stores the ArrayBuffer object in a property called "data"
                    return { data : data };
                }
            }
        });
        // var myPdf = myService.$getPdf();
        // myPdf.$promise.then(function() {
        //     var docInitParams = {
        //         data: myPdf.data
        //     };
        //
        //     PDFJS.getDocument(docInitParams).then(function (pdf) {
        //         console.dir(pdf);
        //     });
        // });

        function initPdf(path){
            // If absolute URL from the remote server is provided, configure the CORS
            // header on that server.
            //
            var url = path;

            //
            // Disable workers to avoid yet another cross-origin issue (workers need
            // the URL of the script to be loaded, and dynamically loading a cross-origin
            // script does not work).
            //
            // PDFJS.disableWorker = true;

            //
            // In cases when the pdf.worker.js is located at the different folder than the
            // pdf.js's one, or the pdf.js is executed via eval(), the workerSrc property
            // shall be specified.
            //
            // PDFJS.workerSrc = '../../build/pdf.worker.js';

            //
            // Asynchronous download PDF
            //
            PDFJS.getDocument(url).then(function getPdfHelloWorld(pdf) {
                //
                // Fetch the first page
                //
                pdf.getPage(1).then(function getPageHelloWorld(page) {
                    var scale = 1.5;
                    var viewport = page.getViewport(scale);

                    //
                    // Prepare canvas using PDF page dimensions
                    //
                    var canvas = document.getElementById('the-canvas');
                    var context = canvas.getContext('2d');
                    canvas.height = viewport.height;
                    canvas.width = viewport.width;

                    //
                    // Render PDF page into canvas context
                    //
                    var renderContext = {
                        canvasContext: context,
                        viewport: viewport
                    };
                    page.render(renderContext);
                });


            });
        }
    }]);

    angular.module('annuityApp.principal', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider.when('/principal', {
            templateUrl: 'modules/principal/principal.html',
            controller: 'principalCtrl'
        });
    }])

    .controller('principalCtrl', ['$scope', function($scope){

    }]);

    angular.module('annuityApp.static', ['ngRoute'])

    .config(['$routeProvider', function($routeProvider) {
        $routeProvider
            .when('/static/guide', {
                templateUrl: 'modules/static/guide.html',
                controller: 'guideCtrl'
            })
            .when('/static/infoReveal', {
                templateUrl: 'modules/static/infoReveal.html',
                controller: 'infoRevealCtrl'
            })
            .when('/static/proandvison', {
                templateUrl: 'modules/static/proandvison.html',
                controller: 'proandvisonCtrl'
            })
            .when('/static/companyOverview', {
                templateUrl: 'modules/static/companyOverview.html',
                controller: 'companyOverviewCtrl'
            })
            .when('/static/goverSumm', {
                templateUrl: 'modules/static/goverSumm.html',
                controller: 'goverSummCtrl'
            })
            .when('/static/yearInfoReveal', {
                templateUrl: 'modules/static/yearInfoReveal.html',
                controller: 'yearInfoRevealCtrl'
            })
            .when('/static/majorMatter', {
                templateUrl: 'modules/static/majorMatter.html',
                controller: 'majorMatterCtrl'
            })
            .when('/static/majorBuss', {
                templateUrl: 'modules/static/majorBuss.html',
                controller: 'majorBussCtrl'
            })
            .when('/static/entManage', {
                templateUrl: 'modules/static/entManage.html',
                controller: 'entManageCtrl'
            })
            .when('/static/entDuty', {
                templateUrl: 'modules/static/entDuty.html',
                controller: 'entDutyCtrl'
            })
            .when('/static/entEquals', {
                templateUrl: 'modules/static/entEquals.html',
                controller: 'entEqualsCtrl'
            })
            .when('/static/entManageEvalSys', {
                templateUrl: 'modules/static/entManageEvalSys.html',
                controller: 'entManageEvalSysCtrl'
            })
            .when('/static/entManageExp', {
                templateUrl: 'modules/static/entManageExp.html',
                controller: 'entManageExpCtrl'
            })
            .when('/static/entManagePlan', {
                templateUrl: 'modules/static/entManagePlan.html',
                controller: 'entManagePlanCtrl'
            })
            .when('/static/entManageSys', {
                templateUrl: 'modules/static/entManageSys.html',
                controller: 'entManageSysCtrl'
            })
            .when('/static/entManageTeam', {
                templateUrl: 'modules/static/entManageTeam.html',
                controller: 'entManageTeamCtrl'
            })
            .when('/static/entPlanflow', {
                templateUrl: 'modules/static/entPlanflow.html',
                controller: 'entPlanflowCtrl'
            })
            .when('/static/entTec', {
                templateUrl: 'modules/static/entTec.html',
                controller: 'entTecCtrl'
            })
            .when('/static/investManage', {
                templateUrl: 'modules/static/investManage.html',
                controller: 'investManageCtrl'
            })
            .when('/static/investBestAbility', {
                templateUrl: 'modules/static/investBestAbility.html',
                controller: 'investBestAbilityCtrl'
            })
            .when('/static/investBestIdea', {
                templateUrl: 'modules/static/investBestIdea.html',
                controller: 'investBestIdeaCtrl'
            })
            .when('/static/investManageExp', {
                templateUrl: 'modules/static/investManageExp.html',
                controller: 'investManageExpCtrl'
            })
            .when('/static/investManageIntroduce', {
                templateUrl: 'modules/static/investManageIntroduce.html',
                controller: 'investManageIntroduceCtrl'
            })
            .when('/static/investPower', {
                templateUrl: 'modules/static/investPower.html',
                controller: 'investPowerCtrl'
            })
            .when('/static/investServerLevel', {
                templateUrl: 'modules/static/investServerLevel.html',
                controller: 'investServerLevelCtrl'
            })
            .when('/static/accountsManage', {
                templateUrl: 'modules/static/accountsManage.html',
                controller: 'accountsManageCtrl'
            })
            .when('/static/accountsManageflow', {
                templateUrl: 'modules/static/accountsManageflow.html',
                controller: 'accountsManageflowCtrl'
            })
            .when('/static/accountsManageGoodness',{
                templateUrl: 'modules/static/accountsManageGoodness.html',
                controller: 'accountsManageGoodnessCtrl'
            })
            .when('/static/accountsManageOutfit',{
                templateUrl: 'modules/static/accountsManageOutfit.html',
                controller: 'accountsManageOutfitCtrl'
            })
            .when('/static/accountsManageServer',{
                templateUrl: 'modules/static/accountsManageServer.html',
                controller: 'accountsManageServerCtrl'
            })
            .when('/static/accountsManageTeam',{
                templateUrl: 'modules/static/accountsManageTeam.html',
                controller: 'accountsManageTeamCtrl'
            })
            .when('/static/operationsManage', {
                templateUrl: 'modules/static/operationsManage.html',
                controller: 'operationsManageCtrl'
            })
            .when('/static/operationsIntroduce', {
                templateUrl: 'modules/static/operationsIntroduce.html',
                controller: 'operationsIntroduceCtrl'
            })
            .when('/static/operationsGoodness', {
                templateUrl: 'modules/static/operationsGoodness.html',
                controller: 'operationsGoodnessCtrl'
            })
            .when('/static/clientServer', {
                templateUrl: 'modules/static/clientServer.html',
                controller: 'clientServerCtrl'
            })
            .when('/static/clientServerPros', {
                templateUrl: 'modules/static/clientServerPros.html',
                controller: 'clientServerProsCtrl'
            })
            .when('/static/clientServerWays', {
                templateUrl: 'modules/static/clientServerWays.html',
                controller: 'clientServerWaysCtrl'
            })
            .when('/static/surplusManage', {
                templateUrl: 'modules/static/surplusManage.html',
                controller: 'surplusManageCtrl'
            })
            .when('/static/surplusContact', {
                templateUrl: 'modules/static/surplusContact.html',
                controller: 'surplusContactCtrl'
            })
            .when('/static/surplusCost', {
                templateUrl: 'modules/static/surplusCost.html',
                controller: 'surplusCostCtrl'
            })
            .when('/static/surplusIntroduce', {
                templateUrl: 'modules/static/surplusIntroduce.html',
                controller: 'surplusIntroduceCtrl'
            })
            .when('/static/surplusServer', {
                templateUrl: 'modules/static/surplusServer.html',
                controller: 'surplusServerCtrl'
            })
            .when('/static/proSolution', {
                templateUrl: 'modules/static/proSolution.html',
                controller: 'proSolutionCtrl'
            })
            .when('/static/proSolutionChat', {
                templateUrl: 'modules/static/proSolutionChat.html',
                controller: 'proSolutionChatCtrl'
            })
            .when('/static/proSolutionEnt', {
                templateUrl: 'modules/static/proSolutionEnt.html',
                controller: 'proSolutionEntCtrl'
            })
            .when('/static/proSolutionExpOne', {
                templateUrl: 'modules/static/proSolutionExpOne.html',
                controller: 'proSolutionExpOneCtrl'
            })
            .when('/static/proSolutionExpTwo', {
                templateUrl: 'modules/static/proSolutionExpTwo.html',
                controller: 'proSolutionExpTwoCtrl'
            })
            .when('/static/proSolutionExpThr', {
                templateUrl: 'modules/static/proSolutionExpThr.html',
                controller: 'proSolutionExpThrCtrl'
            })
            .when('/static/proSolutionInvest', {
                templateUrl: 'modules/static/proSolutionInvest.html',
                controller: 'proSolutionInvestCtrl'
            })
            .when('/static/proSolutionNice', {
                templateUrl: 'modules/static/proSolutionNice.html',
                controller: 'proSolutionNiceCtrl'
            })
            .when('/static/proSolutionNotWorry', {
                templateUrl: 'modules/static/proSolutionNotWorry.html',
                controller: 'proSolutionNotWorryCtrl'
            })
            .when('/static/proSolutionShare', {
                templateUrl: 'modules/static/proSolutionShare.html',
                controller: 'proSolutionShareCtrl'
            })
            .when('/static/proSolutionShit', {
                templateUrl: 'modules/static/proSolutionShit.html',
                controller: 'proSolutionShitCtrl'
            })
            .when('/static/proSolutionSuccessExp', {
                templateUrl: 'modules/static/proSolutionSuccessExp.html',
                controller: 'proSolutionSuccessExpCtrl'
            })
            .when('/static/annuityKnowledge', {
                templateUrl: 'modules/static/annuityKnowledge.html',
                controller: 'annuityKnowledgeCtrl'
            })
            .when('/static/knowledgeOne', {
                templateUrl: 'modules/static/annuityKnowledgeOne.html',
                controller: 'annuityKnowledgeOCtrl'
            })
            .when('/static/knowledgeTwo', {
                templateUrl: 'modules/static/annuityKnowledgeTwo.html',
                controller: 'annuityKnowledgeTCtrl'
            })
            .when('/static/knowledgeThr', {
                templateUrl: 'modules/static/annuityKnowledgeThr.html',
                controller: 'annuityKnowledgeRCtrl'
            })
            .when('/static/knowledgeFou', {
                templateUrl: 'modules/static/annuityKnowledgeFou.html',
                controller: 'annuityKnowledgeFCtrl'
            })
            .when('/static/shareMeetReport', {
                templateUrl: 'modules/static/shareMeetReport.html',
                controller: 'shareMeetReportCtrl'
            })
            .when('/static/dsjl', {
                templateUrl: 'modules/static/dsjl.html',
                controller: 'dsjlCtrl'
            })
            .when('/static/jsjl', {
                templateUrl: 'modules/static/jsjl.html',
                controller: 'jsjlCtrl'
            })
            .when('/static/gjjl', {
                templateUrl: 'modules/static/gjjl.html',
                controller: 'gjjlCtrl'
            })
            .when('/static/zygd', {
                templateUrl: 'modules/static/zygd.html',
                controller: 'zygdCtrl'
            })
            .when('/static/bmsz', {
                templateUrl: 'modules/static/bmsz.html',
                controller: 'bmszCtrl'
            })
    }])

    .controller('bmszCtrl', ['$scope', function($scope){

    }])

    .controller('zygdCtrl', ['$scope', function($scope){

    }])

    .controller('gjjlCtrl', ['$scope', function($scope){

    }])

    .controller('jsjlCtrl', ['$scope', function($scope){

    }])

    .controller('dsjlCtrl', ['$scope', function($scope){

    }])

    .controller('shareMeetReportCtrl', ['$scope', 'infoService', function($scope, infoService){
        //default config
        $scope.infoList = [];

        initInfoList();

        //init infoList
        function initInfoList(){
            loadRemoteData({
                method: "articleList",
                channelId: 1062,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data){
            $scope.infoList = data.articleList;
            $scope.totalNum = data.totalNum;
        }

        function loadRemoteData(params){
            infoService.getInfoList(params).then(function(data){
                applyRemoteData(data);
            });
        }
    }])

    .controller('annuityKnowledgeOCtrl', ['$scope', function($scope){

    }])

    .controller('annuityKnowledgeTCtrl', ['$scope', function($scope){

    }])

    .controller('annuityKnowledgeRCtrl', ['$scope', function($scope){

    }])

    .controller('annuityKnowledgeFCtrl', ['$scope', function($scope){

    }])

    .controller('guideCtrl', ['$scope', function($scope){

    }])

    .controller('infoRevealCtrl', ['$scope', function($scope){

    }])

    .controller('companyOverviewCtrl', ['$scope', function($scope){

    }])

    .controller('goverSummCtrl', ['$scope', function($scope){

    }])

    .controller('yearInfoRevealCtrl', ['$scope', 'infoService', function($scope, infoService){

        $scope.title = "年度信息披露";
        $scope.infoList = [];

        initInfoList();

        //init infoList
        function initInfoList(){
            loadRemoteData({
                method: "articleList",
                channelId: 643,
                channelLevel: 2,
                number: 10
            });
        }

        function applyRemoteData(data){
            $scope.infoList = data.articleList;
        }

        function loadRemoteData(params){
            infoService.getInfoList(params).then(function(data){
                applyRemoteData(data);
            });
        }
    }])

    .controller('entManageCtrl', ['$scope', function($scope){

    }])

    .controller('entEqualsCtrl', ['$scope', function($scope){

    }])

    .controller('entDutyCtrl', ['$scope', function($scope){

    }])

    .controller('entManageEvalSysCtrl', ['$scope', function($scope){

    }])

    .controller('entManageExpCtrl', ['$scope', function($scope){

    }])

    .controller('entManagePlanCtrl', ['$scope', function($scope){

    }])

    .controller('entManageSysCtrl', ['$scope', function($scope){

    }])

    .controller('entManageTeamCtrl', ['$scope', function($scope){

    }])

    .controller('investManageCtrl', ['$scope', function($scope){

    }])

    .controller('investBestAbilityCtrl', ['$scope', function($scope){

    }])

    .controller('investBestIdeaCtrl', ['$scope', function($scope){

    }])

    .controller('investManageExpCtrl', ['$scope', function($scope){

    }])

    .controller('investManageIntroduceCtrl', ['$scope', function($scope){

    }])

    .controller('investPowerCtrl', ['$scope', function($scope){

    }])

    .controller('investServerLevelCtrl', ['$scope', function($scope){

    }])

    .controller('accountsManageCtrl', ['$scope', function($scope){

    }])

    .controller('accountsManageflowCtrl', ['$scope', function($scope){

    }])

    .controller('accountsManageGoodnessCtrl', ['$scope', function($scope){

    }])

    .controller('accountsManageOutfitCtrl', ['$scope', function($scope){

    }])

    .controller('accountsManageServerCtrl', ['$scope', function($scope){

    }])

    .controller('accountsManageTeamCtrl', ['$scope', function($scope){

    }])

    .controller('operationsManageCtrl', ['$scope', function($scope){

    }])

    .controller('operationsIntroduceCtrl', ['$scope', function($scope){

    }])

    .controller('operationsGoodnessCtrl', ['$scope', function($scope){

    }])

    .controller('clientServerCtrl', ['$scope', function($scope){

    }])

    .controller('clientServerWaysCtrl', ['$scope', function($scope){

    }])

    .controller('clientServerProsCtrl', ['$scope', function($scope){

    }])

    .controller('surplusManageCtrl', ['$scope', function($scope){

    }])

    .controller('surplusContactCtrl', ['$scope', function($scope){

    }])

    .controller('surplusIntroduceCtrl', ['$scope', function($scope){

    }])

    .controller('surplusServerCtrl', ['$scope', function($scope){

    }])

    .controller('surplusCostCtrl', ['$scope', function($scope){

    }])

    .controller('proSolutionCtrl', ['$scope', function($scope){

    }])

    .controller('proSolutionChatCtrl', ['$scope', '$routeParams', function($scope, $routeParams){
        //from hooks
        var hooks = {
            "inner": function(){
                $scope.backLink = "#/static/proSolutionEnt";
            },
            "outer": function(){
                $scope.backLink = "#/static/proSolution";
            },
            "direct": function(){
                $scope.backLink = "#/main";
            }
        };

        //default $scope
        $scope.backLink = "";

        (!! $routeParams.from && hooks[$routeParams.from] || hooks["direct"])();

    }])

    .controller('proSolutionEntCtrl', ['$scope', function($scope){

    }])

    .controller('proSolutionExpOneCtrl', ['$scope', function($scope){

    }])

    .controller('proSolutionExpTwoCtrl', ['$scope', function($scope){

    }])

    .controller('proSolutionExpThrCtrl', ['$scope', function($scope){

    }])

    .controller('proSolutionInvestCtrl', ['$scope', function($scope){

    }])

    .controller('proSolutionNiceCtrl', ['$scope', function($scope){

    }])

    .controller('proSolutionNotWorryCtrl', ['$scope', function($scope){

    }])

    .controller('proSolutionShareCtrl', ['$scope', '$routeParams', function($scope, $routeParams){

            //from hooks
            var hooks = {
                "inner": function(){
                    $scope.backLink = "#/static/proSolutionEnt";
                },
                "outer": function(){
                    $scope.backLink = "#/static/proSolution";
                },
                "direct": function(){
                    $scope.backLink = "#/main";
                }
            };

            //default $scope
            $scope.backLink = "";

            (!! $routeParams.from && hooks[$routeParams.from] || hooks["direct"])();
    }])

    .controller('proSolutionShitCtrl', ['$scope', function($scope){

    }])

    .controller('proSolutionSuccessExpCtrl', ['$scope', function($scope){

    }])

    .controller('annuityKnowledgeCtrl', ['$scope', function($scope){

    }])

    .controller('majorMatterCtrl', ['$scope', 'infoService', function($scope, infoService){
        $scope.title = "重大事件";
        $scope.infoList = [];

        initInfoList();

        //init infoList
        function initInfoList(){
            loadRemoteData({
                method: "articleList",
                channelId: 644,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data){
            $scope.infoList = data.articleList;
        }

        function loadRemoteData(params){
            infoService.getInfoList(params).then(function(data){
                applyRemoteData(data);
            });
        }
    }])

    .controller('majorBussCtrl', ['$scope', 'infoService', function($scope, infoService){
        $scope.title = "重大事件";
        $scope.infoList = [];

        initInfoList();

        //init infoList
        function initInfoList(){
            loadRemoteData({
                method: "articleList",
                channelId: 645,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data){
            $scope.infoList = data.articleList;
        }

        function loadRemoteData(params){
            infoService.getInfoList(params).then(function(data){
                applyRemoteData(data);
            });
        }
    }])

    .controller('proandvisonCtrl', ['$scope', 'infoService', function($scope, infoService){
        $scope.title = "产品和条款";
        $scope.infoList = [];

        initInfoList();

        //init infoList
        function initInfoList(){
            loadRemoteData({
                method: "articleList",
                channelId: 1068,
                channelLevel: 2,
                number: 20
            });
        }

        function applyRemoteData(data){
            $scope.infoList = data.articleList;
        }

        function loadRemoteData(params){
            infoService.getInfoList(params).then(function(data){
                applyRemoteData(data);
            });
        }
    }])

'use strict'

angular.module('annuityApp')
  .config(['$routeProvider','$locationProvider',function($routeProvider,$locationProvider) {
      $routeProvider.otherwise({
          redirectTo: '/main'
      });
    //$locationProvider.html5Mode(true);
  }])
  .run(['$rootScope','$location',function($rootScope,$location){
      $rootScope.$on("$routeChangeSuccess", function (event, current, previous, rejection) {
        $rootScope.previousRouter = previous;
      });
  }]);

'use strict';

angular.module('annuityApp.directive', [])
  .directive('appVersion', ['version', function(version) {
    return function(scope, elm, attrs) {
      elm.text(version);
    };
  }]);
'use strict';

angular.module('annuityApp.filter', [])
.filter('interpolate', ['version', function(version) {
  return function(text) {
    return String(text).replace(/\%VERSION\%/mg, version);
  };
}]);
angular.module('annuityApp.infoService', []).factory('infoService',['$http', '$q', function($http, $q){

    // customize url
    // toggle test or deploy
    var url = 'http://www.pingan.com/cms-tmplt/portalJsonpController.do?callback=JSON_CALLBACK';

    var getList = function(params){
        var request = $http({
            method: "jsonp",
            url: url,
            params: params
        });
        return( request.then( handleSuccess, handleError ) );
    };

    var getInfo = function(params){
        var request = $http({
            method: "jsonp",
            url: url,
            params: params
        });
        return( request.then( handleSuccess, handleError ) );
    }

    function handleError( response ) {

        if (! angular.isObject( response.data ) ||! response.data.message) {

            return( $q.reject( "An unknown error occurred." ) );

        }

        // Otherwise, use expected error message.
        return( $q.reject( response.data.message ) );

    }

    function handleSuccess( response ) {
        return( response.data );

    }

    //can top first
    return {
      'getInfoList': getList,
      'getDetails': getInfo
    };

}])
